/home/hadoop/spark/bin/spark-submit \
--master yarn \
--py-files /home/hadoop/datasets/Spark_API/Spark_Submit_Jars/PySpark/artifacts.zip \
/home/hadoop/datasets/Spark_API/Spark_Submit_Jars/PySpark/EtlCountries.py